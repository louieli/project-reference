/*
    EasyHook - The reinvention of Windows API hooking
 
    Copyright (C) 2008 Christoph Husse

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

    Please visit http://www.codeplex.com/easyhook for more information
    about the project and latest updates.

PLEASE NOTE:
    The LGPL allows you to sell propritary software based on this library
    (EasyHook) without releasing the source code for your application.
    This is a big difference to the original GPL. Refer to the attached
    "LICENSE" document for more information about the LGPL!
 
    To wrap it up (without warranty):
        
        1)  You are granted to sell any software that uses EasyHook over
            DLL or NET bindings. This is covered by the native API and the 
            managed interface.
        2)  You are NOT granted to sell any software that includes parts
            of the EasyHook source code or any modification! If you want
            to modify EasyHook, you are forced to release your work under
            the LGPL or GPL... Of course this only applies to the library
            itself. For example you could release a modification of EasyHook
            under LGPL, while still being able to release software, which
            takes advantage of this modification over DLL or NET bindings,
            under a proprietary license!
        3)  You shall include a visible hint in your software that EasyHook
            is used as module and also point out, that this module in
            particular is released under the terms of the LGPL and NOT
            under the terms of your software (assuming that your software
            has another license than LGPL or GPL).
 
    I decided to release EasyHook under LGPL to prevent commercial abuse
    of this free work. I didn't release it under GPL, because I also want to
    address commercial vendors which are more common under Windows.

BUG REPORTS:

    Reporting bugs is the only chance to get them fixed! Don't consider your
    report useless... I will fix any serious bug within a short time! Bugs with
    lower priority will always be fixed in the next release...

DONATIONS:

    I want to add support for Itanium (II - III) processors. If you have any hardware
    that you don't need anymore or could donate, which >supports< a recent Windows
    Itanium edition (Windows license is not required), please contact me. Of course we 
    could discuss a reasonable sponsorship reference for your company. Money for
    buying such hardware is also appreciated...
*/
#include "stdafx.h"

void LhFreeMemory(PLOCAL_HOOK_INFO* RefHandle)
{
/*
Description:

    Will release the memory for a given hook.

Parameters:

    - RefHandle

        A pointer to a valid hook handle. It will be set to NULL
        by this method!
*/

#if defined(_M_X64) && !defined(DRIVER)
    VirtualFree(*RefHandle, 0, MEM_RELEASE);
#else
    RtlFreeMemory(*RefHandle);
#endif

    *RefHandle = NULL;
}

///////////////////////////////////////////////////////////////////////////////////
/////////////////////// LhAllocateMemory
///////////////////////////////////////////////////////////////////////////////////
void* LhAllocateMemory(void* InEntryPoint)
{
/*
Description:

    Allocates one page of hook specific memory.

Parameters:

    - InEntryPoint

        Ignored for 32-Bit versions and drivers. In 64-Bit user mode, the returned
        pointer will always be in a 31-bit boundary around this parameter. This way
        a relative jumper can still be placed instead of having to consume much more entry
        point bytes for an absolute jump!

Returns:

    NULL if no memory could be allocated, a valid pointer otherwise.

*/

    UCHAR*			    Res = NULL;

#if defined(_M_X64) && !defined(DRIVER)
    LONGLONG            Base;
    LONGLONG		    iStart;
    LONGLONG		    iEnd;
    LONGLONG            Index;

#endif
	
#if !defined(DRIVER)
    SYSTEM_INFO		    SysInfo;
    ULONG               PAGE_SIZE;

    GetSystemInfo(&SysInfo);

    PAGE_SIZE = SysInfo.dwPageSize;
#endif


    // reserve page with execution privileges
#if defined(_M_X64) && !defined(DRIVER)

    /*
        Reserve memory around entry point...
    */
    iStart = ((LONGLONG)InEntryPoint) - ((LONGLONG)0x7FFFFF00);
    iEnd = ((LONGLONG)InEntryPoint) + ((LONGLONG)0x7FFFFF00);

    if(iStart < (LONGLONG)SysInfo.lpMinimumApplicationAddress)
        iStart = (LONGLONG)SysInfo.lpMinimumApplicationAddress; // shall not be null, because then VirtualAlloc() will not work as expected

    if(iEnd > (LONGLONG)SysInfo.lpMaximumApplicationAddress)
        iEnd = (LONGLONG)SysInfo.lpMaximumApplicationAddress;

    // we are trying to get memory as near as possible to relocate most RIP-relative addressings
    for(Base = (LONGLONG)InEntryPoint, Index = 0; ; Index += PAGE_SIZE)
    {
		if(Base + Index < iEnd)
		{
			if((Res = (UCHAR*)VirtualAlloc((void*)(Base + Index), PAGE_SIZE, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE)) != NULL)
				break;
		}

        if(Base - Index > iStart)
        {
	        if((Res = (BYTE*)VirtualAlloc((void*)(Base - Index), PAGE_SIZE, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE)) != NULL)
		        break;
        }
    }

    if(Res == NULL)
	    return NULL;
#else
    // in 32-bit mode the trampoline will always be reachable
    if((Res = (UCHAR*)RtlAllocateMemory(TRUE, PAGE_SIZE)) == NULL)
        return NULL;

#endif

    return Res;
}