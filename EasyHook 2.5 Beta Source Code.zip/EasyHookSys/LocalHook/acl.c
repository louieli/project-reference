/*
    EasyHook - The reinvention of Windows API hooking
 
    Copyright (C) 2008 Christoph Husse

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

    Please visit http://www.codeplex.com/easyhook for more information
    about the project and latest updates.

PLEASE NOTE:
    The LGPL allows you to sell propritary software based on this library
    (EasyHook) without releasing the source code for your application.
    This is a big difference to the original GPL. Refer to the attached
    "LICENSE" document for more information about the LGPL!
 
    To wrap it up (without warranty):
        
        1)  You are granted to sell any software that uses EasyHook over
            DLL or NET bindings. This is covered by the native API and the 
            managed interface.
        2)  You are NOT granted to sell any software that includes parts
            of the EasyHook source code or any modification! If you want
            to modify EasyHook, you are forced to release your work under
            the LGPL or GPL... Of course this only applies to the library
            itself. For example you could release a modification of EasyHook
            under LGPL, while still being able to release software, which
            takes advantage of this modification over DLL or NET bindings,
            under a proprietary license!
        3)  You shall include a visible hint in your software that EasyHook
            is used as module and also point out, that this module in
            particular is released under the terms of the LGPL and NOT
            under the terms of your software (assuming that your software
            has another license than LGPL or GPL).
 
    I decided to release EasyHook under LGPL to prevent commercial abuse
    of this free work. I didn't release it under GPL, because I also want to
    address commercial vendors which are more common under Windows.

BUG REPORTS:

    Reporting bugs is the only chance to get them fixed! Don't consider your
    report useless... I will fix any serious bug within a short time! Bugs with
    lower priority will always be fixed in the next release...

DONATIONS:

    I want to add support for Itanium (II - III) processors. If you have any hardware
    that you don't need anymore or could donate, which >supports< a recent Windows
    Itanium edition (Windows license is not required), please contact me. Of course we 
    could discuss a reasonable sponsorship reference for your company. Money for
    buying such hardware is also appreciated...
*/
#include "stdafx.h"

LONG LhSetACL(
            HOOK_ACL* InAcl,
            BOOL InIsExclusive,
            ULONG* InProcessIdList,
            ULONG InProcessCount)
{
/*
Description:

    This method is used internally to provide a generic interface to
    either the global or local hook ACLs.
    
Parameters:
    - InAcl
        NULL if you want to set the global ACL.
        Any LOCAL_HOOK_INFO::LocalACL to set the hook specific ACL.

    - InIsExclusive
        TRUE if all listed process shall be excluded from interception,
        FALSE otherwise

    - InProcessIdList
        An array of process IDs. If you specific zero for an entry in this array,
        it will be automatically replaced with the calling process ID.

    - InProcessCount
        The count of entries listed in the process ID list. This value must not exceed
        MAX_ACE_COUNT! 
*/

    ULONG           Index;

    ASSERT(IsValidPointer(InAcl, sizeof(HOOK_ACL)));

    if(InProcessCount > MAX_ACE_COUNT)
        return STATUS_INVALID_PARAMETER_2;

    if(!IsValidPointer(InProcessIdList, InProcessCount * sizeof(ULONG)))
        return STATUS_INVALID_PARAMETER_1;

    for(Index = 0; Index < InProcessCount; Index++)
    {
        if(InProcessIdList[Index] == 0)
            InProcessIdList[Index] = PsGetCurrentProcessId();
    }

    // set ACL...
    InAcl->IsExclusive = InIsExclusive;
    InAcl->Count = InProcessCount;

    RtlCopyMemory(InAcl->Entries, InProcessIdList, InProcessCount * sizeof(ULONG));

    return STATUS_SUCCESS;
}

EASYHOOK_NT_EXPORT LhSetInclusiveACL(
            ULONG* InProcessIdList,
            ULONG InProcessCount,
            TRACED_HOOK_HANDLE InHandle)
{
/*
Description:

    Sets an inclusive hook local ACL based on the given process ID list.
    Only processs in this list will be intercepted by the hook. If the
    global ACL also is inclusive, then all processs stated there are
    intercepted too.

Parameters:
    - InProcessIdList
        An array of process IDs. If you specific zero for an entry in this array,
        it will be automatically replaced with the calling process ID.

    - InProcessCount
        The count of entries listed in the process ID list. This value must not exceed
        MAX_ACE_COUNT! 

    - InHandle
        The hook handle whose local ACL is going to be set.
*/
    PLOCAL_HOOK_INFO        Handle;

    if(!LhIsValidHandle(InHandle, &Handle))
        return STATUS_INVALID_PARAMETER_3;

    return LhSetACL(&Handle->LocalACL, FALSE, InProcessIdList, InProcessCount);
}

EASYHOOK_NT_EXPORT LhSetExclusiveACL(
            ULONG* InProcessIdList,
            ULONG InProcessCount,
            TRACED_HOOK_HANDLE InHandle)
{
/*
Description:

    Sets an inclusive hook local ACL based on the given process ID list.
    
Parameters:
    - InProcessIdList
        An array of process IDs. If you specific zero for an entry in this array,
        it will be automatically replaced with the calling process ID.

    - InProcessCount
        The count of entries listed in the process ID list. This value must not exceed
        MAX_ACE_COUNT! 

    - InHandle
        The hook handle whose local ACL is going to be set.
*/
    PLOCAL_HOOK_INFO        Handle;

    if(!LhIsValidHandle(InHandle, &Handle))
        return STATUS_INVALID_PARAMETER_3;

    return LhSetACL(&Handle->LocalACL, TRUE, InProcessIdList, InProcessCount);
}

EASYHOOK_NT_EXPORT LhSetGlobalInclusiveACL(
            ULONG* InProcessIdList,
            ULONG InProcessCount)
{
/*
Description:

    Sets an inclusive global ACL based on the given process ID list.
    
Parameters:
    - InProcessIdList
        An array of process IDs. If you specific zero for an entry in this array,
        it will be automatically replaced with the calling process ID.

    - InProcessCount
        The count of entries listed in the process ID list. This value must not exceed
        MAX_ACE_COUNT! 
*/
    return LhSetACL(LhBarrierGetAcl(), FALSE, InProcessIdList, InProcessCount);
}

EASYHOOK_NT_EXPORT LhSetGlobalExclusiveACL(
            ULONG* InProcessIdList,
            ULONG InProcessCount)
{
/*
Description:

    Sets an exclusive global ACL based on the given process ID list.
    
Parameters:
    - InProcessIdList
        An array of process IDs. If you specific zero for an entry in this array,
        it will be automatically replaced with the calling process ID.

    - InProcessCount
        The count of entries listed in the process ID list. This value must not exceed
        MAX_ACE_COUNT! 
*/
    return LhSetACL(LhBarrierGetAcl(), TRUE, InProcessIdList, InProcessCount);
}