/*
    EasyHook - The reinvention of Windows API hooking
 
    Copyright (C) 2008 Christoph Husse

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

    Please visit http://www.codeplex.com/easyhook for more information
    about the project and latest updates.

PLEASE NOTE:
    The LGPL allows you to sell propritary software based on this library
    (EasyHook) without releasing the source code for your application.
    This is a big difference to the original GPL. Refer to the attached
    "LICENSE" document for more information about the LGPL!
 
    To wrap it up (without warranty):
        
        1)  You are granted to sell any software that uses EasyHook over
            DLL or NET bindings. This is covered by the native API and the 
            managed interface.
        2)  You are NOT granted to sell any software that includes parts
            of the EasyHook source code or any modification! If you want
            to modify EasyHook, you are forced to release your work under
            the LGPL or GPL... Of course this only applies to the library
            itself. For example you could release a modification of EasyHook
            under LGPL, while still being able to release software, which
            takes advantage of this modification over DLL or NET bindings,
            under a proprietary license!
        3)  You shall include a visible hint in your software that EasyHook
            is used as module and also point out, that this module in
            particular is released under the terms of the LGPL and NOT
            under the terms of your software (assuming that your software
            has another license than LGPL or GPL).
 
    I decided to release EasyHook under LGPL to prevent commercial abuse
    of this free work. I didn't release it under GPL, because I also want to
    address commercial vendors which are more common under Windows.

BUG REPORTS:

    Reporting bugs is the only chance to get them fixed! Don't consider your
    report useless... I will fix any serious bug within a short time! Bugs with
    lower priority will always be fixed in the next release...

DONATIONS:

    I want to add support for Itanium (II - III) processors. If you have any hardware
    that you don't need anymore or could donate, which >supports< a recent Windows
    Itanium edition (Windows license is not required), please contact me. Of course we 
    could discuss a reasonable sponsorship reference for your company. Money for
    buying such hardware is also appreciated...
*/
#include "stdafx.h"


typedef struct _DRIVER_NOTIFICATION_
{
	SLIST_ENTRY		ListEntry;
	ULONG			ProcessId;
}DRIVER_NOTIFICATION, *PDRIVER_NOTIFICATION;

NTSTATUS DriverEntry(
	IN PDRIVER_OBJECT InDriverObject,
	IN PUNICODE_STRING InRegistryPath);

NTSTATUS EasyHookDispatchCreate(
	IN PDEVICE_OBJECT InDeviceObject,
	IN PIRP	InIrp);

NTSTATUS EasyHookDispatchClose(
	IN PDEVICE_OBJECT InDeviceObject,
	IN PIRP InIrp);

NTSTATUS EasyHookDispatchDeviceControl(
	IN PDEVICE_OBJECT InDeviceObject,
	IN PIRP InIrp);

VOID EasyHookUnload(IN PDRIVER_OBJECT DriverObject);

#ifdef ALLOC_PRAGMA

#pragma alloc_text(INIT, DriverEntry)
#pragma alloc_text(PAGE, EasyHookDispatchCreate)
#pragma alloc_text(PAGE, EasyHookDispatchClose)
#pragma alloc_text(PAGE, EasyHookDispatchDeviceControl)
#pragma alloc_text(PAGE, EasyHookUnload)

#endif

void OnImageLoadNotification(
    IN PUNICODE_STRING  FullImageName,
    IN HANDLE  ProcessId, // where image is mapped
    IN PIMAGE_INFO  ImageInfo)
{
	LhModuleListChanged = TRUE;
}

/**************************************************************

Description:

	Initializes the driver and also loads the system specific PatchGuard
	information.
*/
NTSTATUS DriverEntry(
	IN PDRIVER_OBJECT		InDriverObject,
	IN PUNICODE_STRING		InRegistryPath)
{
	NTSTATUS						Status;    
    UNICODE_STRING					NtDeviceName;
	UNICODE_STRING					DosDeviceName;
    PEASYHOOK_DEVICE_EXTENSION		DeviceExtension;
	PDEVICE_OBJECT					DeviceObject = NULL;
	BOOLEAN							SymbolicLink = FALSE;

	/*
		Create device...
	*/
    RtlInitUnicodeString(&NtDeviceName, EASYHOOK_DEVICE_NAME);

    Status = IoCreateDevice(
		InDriverObject,
		sizeof(EASYHOOK_DEVICE_EXTENSION),		// DeviceExtensionSize
		&NtDeviceName,					// DeviceName
		FILE_DEVICE_EASYHOOK,			// DeviceType
		0,								// DeviceCharacteristics
		TRUE,							// Exclusive
		&DeviceObject					// [OUT]
		);

	if (!NT_SUCCESS(Status))
		goto ERROR_ABORT;

	/*
		Expose interfaces...
	*/
	DeviceExtension = (PEASYHOOK_DEVICE_EXTENSION)DeviceObject->DeviceExtension;
	DeviceExtension->MaxVersion = EASYHOOK_INTERFACE_v_1;

	DeviceExtension->API_v_1.RtlGetLastError = RtlGetLastError;
	DeviceExtension->API_v_1.RtlGetLastErrorString = RtlGetLastErrorString;
	DeviceExtension->API_v_1.LhInstallHook = LhInstallHook;
	DeviceExtension->API_v_1.LhUninstallHook = LhUninstallHook;
	DeviceExtension->API_v_1.LhWaitForPendingRemovals = LhWaitForPendingRemovals;
	DeviceExtension->API_v_1.LhBarrierGetCallback = LhBarrierGetCallback;
	DeviceExtension->API_v_1.LhBarrierGetReturnAddress = LhBarrierGetReturnAddress;
	DeviceExtension->API_v_1.LhBarrierGetAddressOfReturnAddress = LhBarrierGetAddressOfReturnAddress;
	DeviceExtension->API_v_1.LhBarrierBeginStackTrace = LhBarrierBeginStackTrace;
	DeviceExtension->API_v_1.LhBarrierEndStackTrace = LhBarrierEndStackTrace;
	DeviceExtension->API_v_1.LhBarrierPointerToModule = LhBarrierPointerToModule;
	DeviceExtension->API_v_1.LhBarrierGetCallingModule = LhBarrierGetCallingModule;
	DeviceExtension->API_v_1.LhBarrierCallStackTrace = LhBarrierCallStackTrace;
	DeviceExtension->API_v_1.LhSetGlobalExclusiveACL = LhSetGlobalExclusiveACL;
	DeviceExtension->API_v_1.LhSetGlobalInclusiveACL = LhSetGlobalInclusiveACL;
	DeviceExtension->API_v_1.LhSetExclusiveACL = LhSetExclusiveACL;
	DeviceExtension->API_v_1.LhSetInclusiveACL = LhSetInclusiveACL;
	DeviceExtension->API_v_1.LhIsProcessIntercepted = LhIsProcessIntercepted;

	/*
		Register for user-mode accessibility and set major functions...
	*/
    RtlInitUnicodeString(&DosDeviceName, EASYHOOK_DOS_DEVICE_NAME);

    if (!NT_SUCCESS(Status = IoCreateSymbolicLink(&DosDeviceName, &NtDeviceName)))
		goto ERROR_ABORT;

	SymbolicLink = TRUE;

    InDriverObject->MajorFunction[IRP_MJ_CREATE] = EasyHookDispatchCreate;
    InDriverObject->MajorFunction[IRP_MJ_CLOSE] = EasyHookDispatchClose;
    InDriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = EasyHookDispatchDeviceControl;
    InDriverObject->DriverUnload = EasyHookUnload;

	// initialize EasyHook
	if (!NT_SUCCESS(Status = LhBarrierProcessAttach()))
		goto ERROR_ABORT;

	PsSetLoadImageNotifyRoutine(OnImageLoadNotification);

    LhCriticalInitialize();

	return LhUpdateModuleInformation();

ERROR_ABORT:

	/*
		Rollback in case of errors...
	*/
	if (SymbolicLink)
		IoDeleteSymbolicLink(&DosDeviceName);

	if (DeviceObject != NULL)
		IoDeleteDevice(DeviceObject);

	return Status;
}

NTSTATUS EasyHookDispatchCreate(
	IN PDEVICE_OBJECT InDeviceObject,
	IN PIRP InIrp)
{
    InIrp->IoStatus.Information = 0;
    InIrp->IoStatus.Status = STATUS_SUCCESS;

    IoCompleteRequest(InIrp, IO_NO_INCREMENT);

    return STATUS_SUCCESS;
}

NTSTATUS EasyHookDispatchClose(
	IN PDEVICE_OBJECT InDeviceObject,
	IN PIRP InIrp)
{
    InIrp->IoStatus.Information = 0;
    InIrp->IoStatus.Status = STATUS_SUCCESS;

    IoCompleteRequest(InIrp, IO_NO_INCREMENT);

    return STATUS_SUCCESS;
}

/************************************************************
	
Description:

	Handles all device requests.

*/
NTSTATUS EasyHookDispatchDeviceControl(
	IN PDEVICE_OBJECT InDeviceObject,
	IN PIRP	InIrp)
{
    InIrp->IoStatus.Information = 0;
    InIrp->IoStatus.Status = STATUS_INVALID_PARAMETER;

    IoCompleteRequest(InIrp, IO_NO_INCREMENT);

    return STATUS_SUCCESS;
}

/***************************************************

Description:

	Release all resources and remove the driver object.
*/
VOID EasyHookUnload(IN PDRIVER_OBJECT InDriverObject)
{
    UNICODE_STRING			DosDeviceName;

    // remove all hooks and shutdown thread barrier...
    LhCriticalFinalize();

    LhBarrierProcessDetach();

	PsRemoveLoadImageNotifyRoutine(OnImageLoadNotification);

    /*
		Delete the symbolic link
    */
    RtlInitUnicodeString(&DosDeviceName, EASYHOOK_DOS_DEVICE_NAME);

    IoDeleteSymbolicLink(&DosDeviceName);

    /*
		Delete the device object
    */

    IoDeleteDevice(InDriverObject->DeviceObject);
}

