﻿/*
    EasyHook - The reinvention of Windows API hooking
 
    Copyright (C) 2008 Christoph Husse

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

    Please visit http://www.codeplex.com/easyhook for more information
    about the project and latest updates.

PLEASE NOTE:
    The LGPL allows you to sell propritary software based on this library
    (EasyHook) without releasing the source code for your application.
    This is a big difference to the original GPL. Refer to the attached
    "LICENSE" document for more information about the LGPL!
 
    To wrap it up (without warranty):
        
        1)  You are granted to sell any software that uses EasyHook over
            DLL or NET bindings. This is covered by the native API and the 
            managed interface.
        2)  You are NOT granted to sell any software that includes parts
            of the EasyHook source code or any modification! If you want
            to modify EasyHook, you are forced to release your work under
            the LGPL or GPL... Of course this only applies to the library
            itself. For example you could release a modification of EasyHook
            under LGPL, while still being able to release software, which
            takes advantage of this modification over DLL or NET bindings,
            under a proprietary license!
        3)  You shall include a visible hint in your software that EasyHook
            is used as module and also point out, that this module in
            particular is released under the terms of the LGPL and NOT
            under the terms of your software (assuming that your software
            has another license than LGPL or GPL).
 
    I decided to release EasyHook under LGPL to prevent commercial abuse
    of this free work. I didn't release it under GPL, because I also want to
    address commercial vendors which are more common under Windows.

BUG REPORTS:

    Reporting bugs is the only chance to get them fixed! Don't consider your
    report useless... I will fix any serious bug within a short time! Bugs with
    lower priority will always be fixed in the next release...

DONATIONS:

    I want to add support for Itanium (II - III) processors. If you have any hardware
    that you don't need anymore or could donate, which >supports< a recent Windows
    Itanium edition (Windows license is not required), please contact me. Of course we 
    could discuss a reasonable sponsorship reference for your company. Money for
    buying such hardware is also appreciated...
*/

using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using EasyHook;
using System.Diagnostics;
using System.IO;

namespace Examples
{
    public class LHTest
    {
        static DMethodA LHTestHookA = new DMethodA(MethodAHooked);
        static DMethodB LHTestHookB = new DMethodB(MethodBHooked);
        static DMethodA LHTestMethodADelegate;
        static DMethodB LHTestMethodBDelegate;
        static IntPtr LHTestMethodA;
        static IntPtr LHTestMethodB;


        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool DMethodA(Int32 InParam1);

        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate Int64 DMethodB(Int32 InParam1, Int32 InParam2, String InParam3);

        static void CheckRuntimeInfo()
        {/*
            ProcessModule Mod = HookRuntimeInfo.CallingUnmanagedModule;
            System.Reflection.Assembly asm = HookRuntimeInfo.CallingManagedModule;
            Stopwatch w = new Stopwatch();
            System.Reflection.Module[] StackTraceA = HookRuntimeInfo.ManagedStackTrace;
            ProcessModule[] StackTraceB = HookRuntimeInfo.UnmanagedStackTrace;
            Object Callback = HookRuntimeInfo.Callback;
            IntPtr ReturnAddr = HookRuntimeInfo.ReturnAddress;
            IntPtr AddrOfReturnAddr = HookRuntimeInfo.AddressOfReturnAddress;
            Boolean IsHandler = HookRuntimeInfo.IsHandlerContext;

            w.Start();

            Mod = HookRuntimeInfo.CallingUnmanagedModule;

            w.Stop();
            Int64 t1 = w.ElapsedTicks;

            w.Reset();
            
            w.Start();

            Callback = HookRuntimeInfo.Callback;
            ReturnAddr = HookRuntimeInfo.ReturnAddress;
            AddrOfReturnAddr = HookRuntimeInfo.AddressOfReturnAddress;
            IsHandler = HookRuntimeInfo.IsHandlerContext;

            w.Stop();
            Int64 t2 = w.ElapsedTicks;*/
        }

        static bool MethodAHooked(Int32 InParam1)
        {
            CheckRuntimeInfo();

            LHTestMethodBDelegate.Invoke(0, 1, "Hallo");

            Interlocked.Increment(ref LHTestCounterMAH);

            return true;
        }

        static Int64 MethodBHooked(Int32 InParam1, Int32 InParam2, String InParam3)
        {
            CheckRuntimeInfo();

            LHTestMethodADelegate.Invoke(0);

            Interlocked.Increment(ref LHTestCounterMBH);

            return 0;
        }

        static bool MethodA(Int32 InParam1)
        {
            Interlocked.Increment(ref LHTestCounterMA);

            return true;
        }


        static Int64 MethodB(Int32 InParam1, Int32 InParam2, String InParam3)
        {
            LHTestMethodADelegate.Invoke(0);

            Interlocked.Increment(ref LHTestCounterMB);

            return 0;
        }

        static void LHTestThread()
        {
            for (int x = 0; x < 10000; x++)
            {
                LHTestMethodBDelegate.Invoke(0, 0, "");
            }

            Interlocked.Increment(ref LHTestThreadCounter);


            if (LHTestThreadCounter == LHTestThreadCount)
                LHTestCompleted.Set();
        }

        static Int32 LHTestThreadCounter = 0;
        static Int32 LHTestCounterMA = 0;
        static Int32 LHTestCounterMB = 0;
        static Int32 LHTestCounterMAH = 0;
        static Int32 LHTestCounterMBH = 0;
        static ManualResetEvent LHTestCompleted = new ManualResetEvent(false);

        const Int32 LHTestThreadCount = 30;


        public static void Run()
        {
            DMethodA MethodADelegate = new DMethodA(MethodA);
            DMethodB MethodBDelegate = new DMethodB(MethodB);

            GC.KeepAlive(MethodADelegate);
            GC.KeepAlive(MethodBDelegate);

            LHTestMethodA = Marshal.GetFunctionPointerForDelegate(MethodADelegate);
            LHTestMethodB = Marshal.GetFunctionPointerForDelegate(MethodBDelegate);

            LocalHook.EnableRIPRelocation();

            // install hooks
            LocalHook[] MyHooks = new LocalHook[]
            {
                LocalHook.Create(
                   LHTestMethodA,
                   LHTestHookA,
                   1),

                LocalHook.Create(
                    LHTestMethodB,
                    LHTestHookB,
                    2),
            };


            LHTestMethodADelegate = (DMethodA)Marshal.GetDelegateForFunctionPointer(LHTestMethodA, typeof(DMethodA));
            LHTestMethodBDelegate = (DMethodB)Marshal.GetDelegateForFunctionPointer(LHTestMethodB, typeof(DMethodB));

            // we want to intercept all threads...
            MyHooks[0].ThreadACL.SetInclusiveACL(new Int32[1]);
            MyHooks[1].ThreadACL.SetInclusiveACL(new Int32[1]);

           // LHTestMethodBDelegate.Invoke(0, 0, "");

            MyHooks[0].ThreadACL.SetExclusiveACL(new Int32[1]);
            MyHooks[1].ThreadACL.SetExclusiveACL(new Int32[1]);

           // LHTestMethodBDelegate.Invoke(0, 0, "");

            /*
             * This is just to make sure that all related objects are referenced.
             * At the beginning there were several objects like delegates that have
             * been collected during execution! The NET-Framework will produce bugchecks
             * in such cases...
             */
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();

            IntPtr t = Marshal.GetFunctionPointerForDelegate(LHTestHookA);

            Int64 t1 = System.Diagnostics.Stopwatch.GetTimestamp();

            for (int i = 0; i < LHTestThreadCount; i++)
            {
                new Thread(new ThreadStart(LHTestThread)).Start();

            }

            LHTestCompleted.WaitOne();

            t1 = ((System.Diagnostics.Stopwatch.GetTimestamp() - t1) * 1000) / System.Diagnostics.Stopwatch.Frequency;

            // verify results
            if ((LHTestCounterMA != LHTestCounterMAH) || (LHTestCounterMAH != LHTestCounterMB) ||
                    (LHTestCounterMB != LHTestCounterMBH) || (LHTestCounterMB != LHTestThreadCount * 10000))
                throw new Exception("LocalHook test failed.");

            Console.WriteLine("Localhook test passed in {0} ms.", t1);
        }
    }
}
