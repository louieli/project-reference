﻿/*
    EasyHook - The reinvention of Windows API hooking
 
    Copyright (C) 2008 Christoph Husse

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

    Please visit http://www.codeplex.com/easyhook for more information
    about the project and latest updates.

PLEASE NOTE:
    The LGPL allows you to sell propritary software based on this library
    (EasyHook) without releasing the source code for your application.
    This is a big difference to the original GPL. Refer to the attached
    "LICENSE" document for more information about the LGPL!
 
    To wrap it up (without warranty):
        
        1)  You are granted to sell any software that uses EasyHook over
            DLL or NET bindings. This is covered by the native API and the 
            managed interface.
        2)  You are NOT granted to sell any software that includes parts
            of the EasyHook source code or any modification! If you want
            to modify EasyHook, you are forced to release your work under
            the LGPL or GPL... Of course this only applies to the library
            itself. For example you could release a modification of EasyHook
            under LGPL, while still being able to release software, which
            takes advantage of this modification over DLL or NET bindings,
            under a proprietary license!
        3)  You shall include a visible hint in your software that EasyHook
            is used as module and also point out, that this module in
            particular is released under the terms of the LGPL and NOT
            under the terms of your software (assuming that your software
            has another license than LGPL or GPL).
 
    I decided to release EasyHook under LGPL to prevent commercial abuse
    of this free work. I didn't release it under GPL, because I also want to
    address commercial vendors which are more common under Windows.

BUG REPORTS:

    Reporting bugs is the only chance to get them fixed! Don't consider your
    report useless... I will fix any serious bug within a short time! Bugs with
    lower priority will always be fixed in the next release...

DONATIONS:

    I want to add support for Itanium (II - III) processors. If you have any hardware
    that you don't need anymore or could donate, which >supports< a recent Windows
    Itanium edition (Windows license is not required), please contact me. Of course we 
    could discuss a reasonable sponsorship reference for your company. Money for
    buying such hardware is also appreciated...
*/

using System;
using System.Collections.Generic;
using System.ServiceProcess;
using System.Text;
using System.Diagnostics;
using System.IO;
using EasyHook;

namespace EasyHookSvc
{
#pragma warning disable 0618

    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main(String[] args)
        {
            String ServiceName = Path.GetFileNameWithoutExtension(Process.GetCurrentProcess().MainModule.FileName);

            if (args.Length == 3)
            {
                /*
                 * This will provide automated GAC removal...
                 */

                // wait for process exit...
                try
                {
                    Process Proc = Process.GetProcessById(Int32.Parse(args[0]));

                    Proc.WaitForExit();
                }
                catch(Exception Info)
                {
                    Config.PrintError("Unable to wait for host termination...\r\n" + Info.ToString());
                }

                // remove assemblies from GAC...
                try
                {                
                    Config.RunCommand("GAC", true, false, ".\\gac.exe", "/nologo /ul \".\\uninstall.gac\" /r OPAQUE \"" +
                        args[1] + "\" \"" + args[2] + "\"");
                }
                catch (Exception Info)
                {
                    Config.PrintError("Unable to cleanup GAC...\r\n" + Info.ToString());
                }

                // remove temp directory...
                Config.RunCommand("Cleanup", false, true, ".\\cleanup.bat", "");
            }
            else if (args.Length == 1)
            {
                /*
                 * This will provide the service interface under admin privileges which
                 * is used to bypass WOW64. Services can't be used because they are only
                 * able to hook services but not applications under latest Vista x64!
                 */

                // we can reuse the service code...
                new InjectionService(ServiceName).OnExecute(args);
            }
            else
            {
                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[] 
			    { 
				    new InjectionService(ServiceName) 
			    };

                ServiceBase.Run(ServicesToRun);
            }
        }
    }
}
