﻿/*
    EasyHook - The reinvention of Windows API hooking
 
    Copyright (C) 2008 Christoph Husse

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

    Please visit http://www.codeplex.com/easyhook for more information
    about the project and latest updates.

PLEASE NOTE:
    The LGPL allows you to sell propritary software based on this library
    (EasyHook) without releasing the source code for your application.
    This is a big difference to the original GPL. Refer to the attached
    "LICENSE" document for more information about the LGPL!
 
    To wrap it up (without warranty):
        
        1)  You are granted to sell any software that uses EasyHook over
            DLL or NET bindings. This is covered by the native API and the 
            managed interface.
        2)  You are NOT granted to sell any software that includes parts
            of the EasyHook source code or any modification! If you want
            to modify EasyHook, you are forced to release your work under
            the LGPL or GPL... Of course this only applies to the library
            itself. For example you could release a modification of EasyHook
            under LGPL, while still being able to release software, which
            takes advantage of this modification over DLL or NET bindings,
            under a proprietary license!
        3)  You shall include a visible hint in your software that EasyHook
            is used as module and also point out, that this module in
            particular is released under the terms of the LGPL and NOT
            under the terms of your software (assuming that your software
            has another license than LGPL or GPL).
 
    I decided to release EasyHook under LGPL to prevent commercial abuse
    of this free work. I didn't release it under GPL, because I also want to
    address commercial vendors which are more common under Windows.

BUG REPORTS:

    Reporting bugs is the only chance to get them fixed! Don't consider your
    report useless... I will fix any serious bug within a short time! Bugs with
    lower priority will always be fixed in the next release...

DONATIONS:

    I want to add support for Itanium (II - III) processors. If you have any hardware
    that you don't need anymore or could donate, which >supports< a recent Windows
    Itanium edition (Windows license is not required), please contact me. Of course we 
    could discuss a reasonable sponsorship reference for your company. Money for
    buying such hardware is also appreciated...
*/
using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Runtime.InteropServices;

namespace EasyHook
{
#pragma warning disable 1591
#pragma warning disable 0618

    public class InjectionLoader
    {
        [StructLayout(LayoutKind.Sequential)]
        class REMOTE_ENTRY_INFO : RemoteHooking.IContext
        {
            public Int32 m_HostPID;
            public IntPtr UserData;
            public Int32 UserDataSize;

            public Int32 HostPID { get { return m_HostPID; } }
        };

        static List<String> ConnectedChannels = new List<String>();

        private static void Release(Type InEntryPoint)
        {
            if (InEntryPoint == null)
                return;

            LocalHook.Release();
        }

        #pragma warning disable 0028
        public static int Main(String InParam)
        {
            HelperServiceInterface Interface;
            Assembly UserAssembly = null;
            Type EntryPoint = null;
            ManagedRemoteInfo RemoteInfo;
            REMOTE_ENTRY_INFO UnmanagedInfo = new REMOTE_ENTRY_INFO();

            if (InParam == null)
                return 0;

            /*
             * We will now connect to our hooking host. This is to provide extensive
             * error information.
             */
            try
            {

                Marshal.PtrToStructure(
                    (IntPtr)Int64.Parse(InParam, System.Globalization.NumberStyles.HexNumber),
                    UnmanagedInfo);

                Byte[] PassThruBytes = new Byte[UnmanagedInfo.UserDataSize];
                MemoryStream PassThruStream = new MemoryStream();
                BinaryFormatter Format = new BinaryFormatter();

                Marshal.Copy(UnmanagedInfo.UserData, PassThruBytes, 0, UnmanagedInfo.UserDataSize);
              
                PassThruStream.Write(PassThruBytes, 0, PassThruBytes.Length);
                PassThruStream.Position = 0;

                RemoteInfo = (ManagedRemoteInfo)Format.Deserialize(PassThruStream);

                Interface = RemoteHooking.IpcConnectClient<HelperServiceInterface>(RemoteInfo.ChannelName);

                // ensure connection...
                Interface.Ping();

                if (!ConnectedChannels.Contains(RemoteInfo.ChannelName))
                {
                    ConnectedChannels.Add(RemoteInfo.ChannelName);

                    return 1;
                }
            }
            catch (Exception ExtInfo)
            {
                Config.PrintError(ExtInfo.ToString());

                return 0;
            }

            try
            {
                
                // adjust host PID in case of WOW64 bypass and service help...
                UnmanagedInfo.m_HostPID = RemoteInfo.HostPID;

                // prepare parameter array
                Object[] ParamArray = new Object[1 + RemoteInfo.UserParams.Length];

                ParamArray[0] = (RemoteHooking.IContext)UnmanagedInfo;

                for (int i = 0; i < RemoteInfo.UserParams.Length; i++)
                {
                    ParamArray[i + 1] = RemoteInfo.UserParams[i];
                }


                /*
                 * After this we are ready to load the user supplied library.
                 */
                Object Instance = null;

                try
                {
                    UserAssembly = Assembly.LoadWithPartialName(RemoteInfo.UserLibrary);

                    // search for user library entry point...
                    Type[] ExportedTypes = UserAssembly.GetExportedTypes();

                    for (int iType = 0; iType < ExportedTypes.Length; iType++)
                    {
                        EntryPoint = ExportedTypes[iType];

                        if (EntryPoint.GetInterface("EasyHook.IEntryPoint") != null)
                            break;

                        EntryPoint = null;
                    }

                    if (EntryPoint == null)
                        throw new EntryPointNotFoundException("The given user library does not export a proper type implementing the 'EasyHook.IEntryPoint' interface.");
          
                    // assemble user parameters and initialize library...
                    Instance = EntryPoint.InvokeMember(null, BindingFlags.Public | BindingFlags.Instance |
                        BindingFlags.CreateInstance, null, null, ParamArray);


                    // notify the host about successful injection...
                    Interface.InjectionCompleted(RemoteHooking.GetCurrentProcessId());
                }
                catch (Exception ExtInfo)
                {
                    // we will now get extensive error information on host side...
                    try
                    {
                        Interface.InjectionException(RemoteHooking.GetCurrentProcessId(), ExtInfo);
                    }
                    finally
                    {
                        Instance = null;

                        Release(EntryPoint);
                    }

                    return -1;
                }

                try
                {
                    /* 
                     * After this it is safe to enter the main method, which will block until assembly unloading...
                     * From now on the user library has to take care about error reporting!
                     */
                    EntryPoint.InvokeMember("Run", BindingFlags.Public | BindingFlags.Instance | BindingFlags.ExactBinding |
                         BindingFlags.InvokeMethod, null, Instance, ParamArray);
                }
                finally
                {
                    Instance = null;

                    Release(EntryPoint);
                }
            }
            catch (Exception ExtInfo)
            {
                Config.PrintWarning(ExtInfo.ToString());

                return -1;
            }
            finally
            {
                if (ConnectedChannels.Contains(RemoteInfo.ChannelName))
                    ConnectedChannels.Remove(RemoteInfo.ChannelName);
            }

            return 0;
        }
    }
}
