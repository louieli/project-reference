﻿/*
    EasyHook - The reinvention of Windows API hooking
 
    Copyright (C) 2008 Christoph Husse

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

    Please visit http://www.codeplex.com/easyhook for more information
    about the project and latest updates.

PLEASE NOTE:
    The LGPL allows you to sell propritary software based on this library
    (EasyHook) without releasing the source code for your application.
    This is a big difference to the original GPL. Refer to the attached
    "LICENSE" document for more information about the LGPL!
 
    To wrap it up (without warranty):
        
        1)  You are granted to sell any software that uses EasyHook over
            DLL or NET bindings. This is covered by the native API and the 
            managed interface.
        2)  You are NOT granted to sell any software that includes parts
            of the EasyHook source code or any modification! If you want
            to modify EasyHook, you are forced to release your work under
            the LGPL or GPL... Of course this only applies to the library
            itself. For example you could release a modification of EasyHook
            under LGPL, while still being able to release software, which
            takes advantage of this modification over DLL or NET bindings,
            under a proprietary license!
        3)  You shall include a visible hint in your software that EasyHook
            is used as module and also point out, that this module in
            particular is released under the terms of the LGPL and NOT
            under the terms of your software (assuming that your software
            has another license than LGPL or GPL).
 
    I decided to release EasyHook under LGPL to prevent commercial abuse
    of this free work. I didn't release it under GPL, because I also want to
    address commercial vendors which are more common under Windows.

BUG REPORTS:

    Reporting bugs is the only chance to get them fixed! Don't consider your
    report useless... I will fix any serious bug within a short time! Bugs with
    lower priority will always be fixed in the next release...

DONATIONS:

    I want to add support for Itanium (II - III) processors. If you have any hardware
    that you don't need anymore or could donate, which >supports< a recent Windows
    Itanium edition (Windows license is not required), please contact me. Of course we 
    could discuss a reasonable sponsorship reference for your company. Money for
    buying such hardware is also appreciated...
*/
using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Runtime.ConstrainedExecution;
using System.Diagnostics;

namespace EasyHook
{
    public partial class LocalHook
    {
        /// <summary>
        /// RIP relocation is disabled by default. If you want to enable it,
        /// just call this method which will attach a debugger to the current
        /// process. There may be circumstances under which this might fail
        /// and this is why it is not done by default. On 32-Bit system this
        /// method will always succeed and do nothing...
        /// </summary>
        public static void EnableRIPRelocation()
        {
            NativeAPI.DbgAttachDebugger();
        }

        /// <summary>
        /// Tries to get the underlying thread ID for a given handle.
        /// </summary>
        /// <remarks>
        /// This is not always possible. The handle has to be opened with <c>THREAD_QUERY_INFORMATION</c>
        /// access. 
        /// </remarks>
        /// <param name="InThreadHandle">A valid thread handle.</param>
        /// <returns>A valid thread ID associated with the given thread handle.</returns>
        /// <exception cref="AccessViolationException">
        /// The given handle was not opened with <c>THREAD_QUERY_INFORMATION</c> access.</exception>
        /// <exception cref="ArgumentException">
        /// The handle is invalid. 
        /// </exception>
        /// <exception cref="NotSupportedException">
        /// Should never occur and just notifies you that a handle to thread ID conversion is not
        /// available on the current platform.
        /// </exception>
        public static Int32 GetThreadIdByHandle(IntPtr InThreadHandle)
        {
            Int32 Result;

            NativeAPI.DbgGetThreadIdByHandle(InThreadHandle, out Result);

            return Result;
        }

        /// <summary>
        /// Tries to get the underlying process ID for a given handle.
        /// </summary>
        /// <remarks>
        /// This is not always possible. The handle has to be opened with <c>PROCESS_QUERY_INFORMATION</c>
        /// access. 
        /// </remarks>
        /// <param name="InProcessHandle">A valid process handle.</param>
        /// <returns>A valid process ID associated with the given process handle.</returns>
        /// <exception cref="AccessViolationException">
        /// The given handle was not opened with <c>PROCESS_QUERY_INFORMATION</c> access.</exception>
        /// <exception cref="ArgumentException">
        /// The handle is invalid. 
        /// </exception>
        /// <exception cref="NotSupportedException">
        /// Should never occur and just notifies you that a handle to thread ID conversion is not
        /// available on the current platform.
        /// </exception>
        public static Int32 GetProcessIdByHandle(IntPtr InProcessHandle)
        {
            Int32 Result;

            NativeAPI.DbgGetProcessIdByHandle(InProcessHandle, out Result);

            return Result;
        }

        [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
        private class UNICODE_STRING
        {
            public Int16 Length;
            public Int16 MaximumLength;
            public String Buffer;
        }

        internal class NameBuffer : CriticalFinalizerObject
        {
            public IntPtr Buffer;
            public Int32 Size;

            public NameBuffer()
            {
                Size = 0;
                Buffer = Marshal.AllocCoTaskMem(0);
            }

            public void Alloc(Int32 InDesiredSize)
            {
                IntPtr Tmp;

                if (InDesiredSize < Size)
                    return;

                if ((Tmp = Marshal.ReAllocCoTaskMem(Buffer, InDesiredSize)) == IntPtr.Zero)
                    throw new OutOfMemoryException("Unable to allocate unmanaged memory.");

                Buffer = Tmp;
                Size = InDesiredSize;
            }

            ~NameBuffer()
            {
                if(Buffer != IntPtr.Zero)
                    Marshal.FreeCoTaskMem(Buffer);

                Buffer = IntPtr.Zero;
            }
        }
        private static NameBuffer Buffer = new NameBuffer();

        /// <summary>
        /// Reads the kernel object name for a given windows usermode handle.
        /// Executes in approx. 100 micro secounds.
        /// </summary>
        /// <remarks><para>
        /// This allows you to translate a handle back to the associated filename for example.
        /// But keep in mind that such names are only valid for kernel service routines, like
        /// <c>NtCreateFile</c>. You won't have success when calling <c>CreateFile</c> on such
        /// object names! The regular windows user mode API has some methods that will allow
        /// you to convert such kernelmode names back into usermode names. I know this because I did it
        /// some years ago but I've already forgotten how it has to be done! I can only give you
        /// some hints: <c>FindFirstVolume()</c>, <c>FindFirstVolumeMountPoint()</c>,
        /// <c>QueryDosDevice()</c>, <c>GetVolumePathNamesForVolumeName()</c>
        /// </para>
        /// <param name="InHandle">A valid usermode handle.</param>
        /// </remarks>
        /// <returns>The kernel object name associated with the given handle.</returns>
        /// <exception cref="ArgumentException">
        /// The given handle is invalid or could not be accessed for unknown reasons.
        /// </exception>
        public static String GetNameByHandle(IntPtr InHandle)
        {
            Int32 RequiredSize;

            NativeAPI.DbgHandleToObjectName(
                InHandle,
                IntPtr.Zero,
                0,
                out RequiredSize);


            lock (Buffer)
            {
                Buffer.Alloc(RequiredSize + 1);

                NativeAPI.DbgHandleToObjectName(
                    InHandle,
                    Buffer.Buffer,
                    RequiredSize,
                    out RequiredSize);

                UNICODE_STRING Result = new UNICODE_STRING();

                Marshal.PtrToStructure(Buffer.Buffer, Result);

                return Result.Buffer;
            }
        }
    }
}
