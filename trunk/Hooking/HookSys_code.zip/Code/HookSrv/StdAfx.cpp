//---------------------------------------------------------------------------
//
// stdafx.cpp
//
// SUBSYSTEM:   Hook system
//				
// MODULE:      Hook server
//
// DESCRIPTION: Source file that includes just the standard includes
//	            HookSrv.pch will be the pre-compiled header
//	            stdafx.obj will contain the pre-compiled type information
// 				
//             
// AUTHOR:		Ivo Ivanov (ivopi@hotmail.com)
// DATE:		2001 December v1.00
//
//---------------------------------------------------------------------------

#include "stdafx.h"


//----------------------------End of the file -------------------------------



